﻿"""Question answering agent with knowledge-base lookup and cognition-aware fallback."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from programming_education_system.agents.base_agent import BaseAgent
from programming_education_system.cognition_judger.cognitive_api_scientific import (
    get_scientific_cognitive_api_sync,
)
from programming_education_system.models.knowledge_base import KnowledgeBase
from programming_education_system.utils.llm_utils import llm_client

logger = logging.getLogger(__name__)


class ThinkingQAAgent:
    """Handles open-ended questions using cognition-aware prompting."""

    def __init__(self) -> None:
        self.name = "ThinkingQAAgent"
        self.cognition_api = get_scientific_cognitive_api_sync()

    async def think_and_answer(
        self, complex_question: str, user_id: str, context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        cognitive_state = await self.cognition_api.get_cognitive_state(user_id)
        learning_params = await self.cognition_api.get_personalized_learning_parameters(
            user_id, "explanation"
        )
        teaching_mode = (context or {}).get("intent_analysis", {}).get("teaching_mode", "explain")
        system_prompt = self._build_system_prompt(cognitive_state, learning_params, teaching_mode)
        retrieval_context = (context or {}).get("retrieval_context", {})
        retrieval_text = (context or {}).get("retrieval_text", "")
        history_text = self._format_recent_history((context or {}).get("recent_history", []))
        user_message = (
            f"学生问题: {complex_question}\n\n"
            f"最近对话:\n{history_text or '无'}\n\n"
            f"检索到的课程资料:\n{retrieval_text or '未检索到课程资料。'}\n\n"
            "回答要求:\n"
            "1. 先判断课程资料是否与学生问题直接相关；不相关时不要硬套资料。\n"
            "2. 相关资料只能作为证据和例子，最终回答必须紧扣学生问题。\n"
            "3. 资料不足时明确说明“课程资料没有直接覆盖”，再用通用编程知识补充。\n"
            "4. 面向编程学习者，用短例子或小练习帮助理解。\n"
            "5. 如果学生是在追问上一轮，只补充当前追问需要的新信息，不要完整重复上一轮答案。\n"
            "6. 不要编造不存在的来源，不要回答与问题无关的内容。"
        )
        if context:
            user_message += f"\n\n其他上下文: {self._compact_context(context)}"
        answer = await llm_client.generate_response(system_prompt, user_message, use_cache=False)
        return {
            "answer": answer,
            "cognitive_level_used": cognitive_state["overall_cognitive_level"],
            "learning_parameters": learning_params,
            "personalization_applied": True,
            "retrieval_context": retrieval_context,
        }

    def _build_system_prompt(
        self,
        cognitive_state: Dict[str, Any],
        learning_params: Dict[str, Any],
        teaching_mode: str = "explain",
    ) -> str:
        level = cognitive_state["overall_cognitive_level"]
        depth = learning_params.get("parameters", {}).get("explanation_depth", 0.7)
        mode_instruction = {
            "hint": "优先给提示和引导问题，不要一开始就给完整答案。",
            "quiz": "解释后给一个 1 分钟小测题来检查理解。",
            "debug": "优先定位错误原因，并给出最小修改建议。",
            "plan": "优先给阶段化学习路径和下一步行动。",
            "explain": "按概念、例子、常见误区、小练习的顺序讲解。",
        }.get(teaching_mode, "按概念、例子、常见误区、小练习的顺序讲解。")
        base_instruction = (
            "回答必须直接回应学生当前问题。"
            "如果检索资料和问题不匹配，要降低资料权重，避免答非所问。"
            "不要因为上下文里出现了某个知识点，就偏离当前问题。"
        )
        if level < 0.4:
            return (
                "你是耐心的编程入门助教。使用简单中文、短步骤和一个具体例子。"
                f"解释深度约 {depth:.1f}。{mode_instruction}{base_instruction}"
            )
        if level < 0.7:
            return (
                "你是实践型编程助教。兼顾概念、例子和常见误区。"
                f"解释深度约 {depth:.1f}。{mode_instruction}{base_instruction}"
            )
        return (
            "你是进阶编程导师。包含更深层推理、取舍和最佳实践。"
            f"解释深度约 {depth:.1f}。{mode_instruction}{base_instruction}"
        )

    @staticmethod
    def _compact_context(context: Dict[str, Any]) -> Dict[str, Any]:
        compact = dict(context)
        compact.pop("retrieval_context", None)
        compact.pop("retrieval_text", None)
        compact.pop("recent_history", None)
        return compact

    @staticmethod
    def _format_recent_history(history: List[Dict[str, Any]], limit: int = 3) -> str:
        lines: List[str] = []
        for index, item in enumerate(history[-limit:], start=1):
            user_input = str(item.get("user_input", "")).strip()
            agent_response = str(item.get("agent_response", "")).strip()
            if not user_input:
                continue
            lines.append(f"{index}. 用户: {user_input[:180]}")
            if agent_response:
                lines.append(f"   助手: {agent_response[:240]}")
        return "\n".join(lines)


class KnowledgeBaseRetrievalAgent:
    """Looks up concise answers from the local knowledge base."""

    def __init__(self) -> None:
        self.knowledge_base = KnowledgeBase()
        self.cognition_api = get_scientific_cognitive_api_sync()
        self._enhance_knowledge_base()

    def _enhance_knowledge_base(self) -> None:
        seeds = {
            "python_basics": [
                {
                    "question": "How do I start learning Python?",
                    "answer": "Start with syntax, variables, conditions, loops, and functions, then practice with small scripts.",
                    "examples": ["Write a calculator, a guess-the-number game, or a todo list."],
                }
            ],
            "interactive_help": [
                {
                    "question": "What can this system do?",
                    "answer": "It can answer programming questions, generate practice exercises, review code, and offer learning suggestions.",
                    "examples": ["Ask for an exercise, request a code review, or ask for a study path."],
                }
            ],
        }
        for topic, items in seeds.items():
            for item in items:
                self.knowledge_base.add_knowledge(topic, item["question"], item["answer"], item["examples"])

    async def retrieve_from_knowledge_base(self, question: str, user_id: str) -> Dict[str, Any]:
        topic = self._infer_topic_from_question(question)
        results = self.knowledge_base.search(question, topic=None if topic == "general_programming" else topic)
        if not results:
            return {"found": False, "answer": ""}

        best_match = results[0]
        if best_match.get("score", 0) < 4.0 or not self._is_directly_relevant(question, best_match):
            return {"found": False, "answer": "", "retrieval_context": self.knowledge_base.build_context(question)}
        cognitive_state = await self.cognition_api.get_cognitive_state(user_id)
        personalized_answer = await self._personalize_knowledge_answer(best_match, cognitive_state)
        return {
            "found": True,
            "answer": personalized_answer,
            "examples": best_match.get("examples", []),
            "source": "knowledge_base",
            "confidence": "high",
            "personalized": True,
            "retrieval_context": self.knowledge_base.build_context(question, limit=3),
            "citations": [
                self._citation_from_result(item)
                for item in results[:3]
            ],
        }

    async def _personalize_knowledge_answer(
        self, knowledge_item: Dict[str, Any], cognitive_state: Dict[str, Any]
    ) -> str:
        base_answer = str(knowledge_item.get("answer", ""))
        level = cognitive_state.get("overall_cognitive_level", 0.5)
        if level < 0.4:
            prefix = "先抓住核心想法："
        elif level < 0.7:
            prefix = "给你一个实用解释："
        else:
            prefix = "先给结论，再补充深层要点："
        return prefix + base_answer

    @staticmethod
    def _infer_topic_from_question(question: str) -> str:
        lowered = question.lower()
        mapping = {
            "data_structures": ["列表", "字典", "集合", "元组", "list", "dict", "stack", "栈", "append"],
            "algorithms": ["算法", "排序", "查找", "递归", "binary", "二分"],
            "oop": ["类", "对象", "继承", "class"],
            "python_basics": ["python", "函数", "变量", "循环", "条件", "def"],
        }
        for topic, keywords in mapping.items():
            if any(keyword in lowered for keyword in keywords):
                return topic
        return "general_programming"

    @staticmethod
    def _is_directly_relevant(question: str, item: Dict[str, Any]) -> bool:
        lowered_question = question.lower()
        searchable = " ".join(
            [
                str(item.get("title", "")),
                str(item.get("question", "")),
                str(item.get("answer", "")),
                str(item.get("text", "")),
                " ".join(str(example) for example in item.get("examples", [])),
            ]
        ).lower()
        required_terms = [
            "append",
            "列表",
            "list",
            "字典",
            "dict",
            "元组",
            "tuple",
            "集合",
            "set",
            "函数",
            "def",
            "return",
            "递归",
            "二分",
            "排序",
            "类",
            "对象",
        ]
        asked_terms = [term for term in required_terms if term in lowered_question]
        if not asked_terms:
            return True
        return all(term in searchable for term in asked_terms)

    @staticmethod
    def _citation_from_result(item: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "chunk_id": item.get("chunk_id", ""),
            "source": item.get("source", "knowledge_base"),
            "url": item.get("url", ""),
            "topic": item.get("topic"),
            "title": item.get("title") or item.get("question"),
            "score": item.get("score"),
            "lexical_score": item.get("lexical_score", 0),
            "vector_score": item.get("vector_score", 0),
            "retrieval_mode": item.get("retrieval_mode", "lexical"),
        }


class QAAgent(BaseAgent):
    """Main question answering agent."""

    def __init__(self, personal_agent) -> None:
        super().__init__("QAAgent")
        self.thinking_agent = ThinkingQAAgent()
        self.kb_agent = KnowledgeBaseRetrievalAgent()
        self.personal_agent = personal_agent
        self.cognition_api = get_scientific_cognitive_api_sync()

    async def answer_question(
        self, question: str, user_id: str, context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        self.log_activity("answering question", {"user_id": user_id})
        context = context or {}
        is_follow_up = self._is_follow_up_question(question, context)
        kb_result = await self.kb_agent.retrieve_from_knowledge_base(question, user_id)
        if not is_follow_up and kb_result.get("found") and kb_result.get("confidence") == "high":
            return {
                "response": kb_result["answer"],
                "examples": kb_result.get("examples", []),
                "source": kb_result.get("source", "knowledge_base"),
                "needs_thinking": False,
                "personalized": kb_result.get("personalized", False),
                "retrieval_context": kb_result.get("retrieval_context", {}),
                "citations": kb_result.get("citations", []),
            }

        topic = self._extract_topic(question)
        if topic == "general_programming":
            topic = self._topic_from_context(context) or topic
        retrieval_context = self.kb_agent.knowledge_base.build_context(question, topic=topic, limit=3)
        if not retrieval_context.get("hits") and topic != "general_programming":
            retrieval_context = self.kb_agent.knowledge_base.build_context(question, topic=None, limit=3)
        retrieval_text = self.kb_agent.knowledge_base.format_context_for_prompt(retrieval_context)
        enriched_context = {
            **(context or {}),
            "retrieval_context": retrieval_context,
            "retrieval_text": retrieval_text,
        }
        thinking_result = await self.thinking_agent.think_and_answer(question, user_id, enriched_context)
        citations = [
            {
                "chunk_id": hit.get("chunk_id", ""),
                "source": hit.get("source", "knowledge_base"),
                "url": hit.get("url", ""),
                "topic": hit.get("topic"),
                "title": hit.get("title"),
                "score": hit.get("score"),
                "lexical_score": hit.get("lexical_score", 0),
                "vector_score": hit.get("vector_score", 0),
                "retrieval_mode": hit.get("retrieval_mode", "lexical"),
            }
            for hit in retrieval_context.get("hits", [])
        ]
        return {
            "response": thinking_result["answer"],
            "examples": [],
            "source": "llm_thinking",
            "needs_thinking": True,
            "cognitive_level_used": thinking_result["cognitive_level_used"],
            "personalized": thinking_result["personalization_applied"],
            "learning_parameters": thinking_result.get("learning_parameters", {}),
            "retrieval_context": retrieval_context,
            "citations": citations,
        }

    @staticmethod
    def _is_follow_up_question(question: str, context: Dict[str, Any]) -> bool:
        if not context.get("recent_history"):
            return False
        stripped = question.strip()
        lowered = stripped.lower()
        follow_up_markers = [
            "再",
            "继续",
            "换个",
            "举例",
            "例子",
            "为什么",
            "那",
            "它",
            "这个",
            "刚才",
            "上一",
            "详细",
            "展开",
            "不懂",
            "什么意思",
            "what about",
            "why",
            "example",
            "more",
        ]
        if any(marker in lowered for marker in follow_up_markers):
            return True
        return len(stripped) <= 18 and not any(
            token in lowered for token in ["python", "函数", "列表", "字典", "算法", "class", "def"]
        )

    @staticmethod
    def _topic_from_context(context: Dict[str, Any]) -> Optional[str]:
        for item in reversed(context.get("recent_history", [])):
            topic = item.get("topic")
            if topic and topic != "general":
                return str(topic)
            analysis = item.get("intent_analysis") or {}
            topic = analysis.get("topic")
            if topic and topic != "general_programming":
                return str(topic)
        conversation_topic = (context.get("conversation_context") or {}).get("last_topic")
        if conversation_topic and conversation_topic != "general":
            return str(conversation_topic)
        return None

    async def process(self, request: Dict[str, Any]) -> Dict[str, Any]:
        question = request["content"]
        user_id = request["user_id"]
        context = {**request.get("context", {}), "intent_analysis": request.get("intent_analysis", {})}
        result = await self.answer_question(question, user_id, context)
        topic = self._extract_topic(question)

        await self.personal_agent.track_user_behavior(
            {
                "user_id": user_id,
                "question_type": "qa",
                "topic": topic,
                "complexity": "complex" if result["needs_thinking"] else "simple",
                "content": question[:100],
                "cognitive_level": result.get("cognitive_level_used", 0.5),
                "personalization_applied": result.get("personalized", False),
            }
        )

        cognitive_insights = await self._get_scientific_cognitive_insights(user_id, topic)
        response_data = {
            "success": True,
            "response": result["response"],
            "details": {
                "source": result["source"],
                "examples": result["examples"],
                "topic": topic,
                "answer_type": "detailed" if result["needs_thinking"] else "quick",
                "personalized": result.get("personalized", False),
                "cognitive_insights": cognitive_insights,
                "retrieval_context": result.get("retrieval_context", {}),
                "citations": result.get("citations", []),
            },
        }
        if result["needs_thinking"] or cognitive_insights.get("needs_improvement", False):
            response_data["details"]["learning_tips"] = await self._generate_scientific_learning_tips(
                user_id, topic
            )
        return response_data

    async def _get_scientific_cognitive_insights(self, user_id: str, topic: str) -> Dict[str, Any]:
        cognitive_state = await self.cognition_api.get_cognitive_state(user_id)
        learning_recs = await self.cognition_api.get_learning_recommendations(user_id, f"study {topic}")
        topic_mastery = self._analyze_topic_mastery(cognitive_state, topic)
        return {
            "current_level": cognitive_state["overall_cognitive_level"],
            "learning_trend": cognitive_state.get("learning_trend", "stable"),
            "topic_mastery": topic_mastery,
            "needs_improvement": topic_mastery < 0.6,
            "recommended_difficulty": learning_recs.get("recommendations", {}).get(
                "recommended_difficulty", "intermediate"
            ),
            "focus_areas": learning_recs.get("recommendations", {}).get("focus_areas", []),
        }

    async def _generate_scientific_learning_tips(self, user_id: str, topic: str) -> List[str]:
        insights = await self._get_scientific_cognitive_insights(user_id, topic)
        level = insights.get("current_level", 0.5)
        tips: List[str] = []
        if level < 0.4:
            tips.extend(
                [
                    "Strengthen the basics first with short daily practice.",
                    "Rebuild the idea using one tiny example before solving a harder problem.",
                ]
            )
        elif level < 0.7:
            tips.extend(
                [
                    "Mix concept review with hands-on coding to reinforce understanding.",
                    "Try a slightly harder variation after you finish a standard example.",
                ]
            )
        else:
            tips.extend(
                [
                    "Compare multiple solutions and reason about tradeoffs.",
                    "Turn this topic into a reusable pattern or utility to deepen mastery.",
                ]
            )
        tips.append(f"Next focus topic: {topic}")
        return tips

    def _analyze_topic_mastery(self, cognitive_state: Dict[str, Any], topic: str) -> float:
        knowledge_domains = cognitive_state.get("knowledge_domains", {})
        topic_to_domain = {
            "python_basics": "python_basics",
            "data_structures": "data_structures",
            "algorithms": "algorithms",
            "oop": "oop",
            "web_development": "python_basics",
            "data_science": "algorithms",
        }
        domain = topic_to_domain.get(topic, "python_basics")
        domain_score = knowledge_domains.get(domain, 0.5)
        understanding_score = cognitive_state.get("cognitive_dimensions", {}).get("understand", 0.5)
        return (domain_score + understanding_score) / 2

    def _extract_topic(self, question: str) -> str:
        lowered = question.lower()
        topic_keywords = {
            "data_structures": ["list", "dict", "tuple", "set", "列表", "字典", "append"],
            "algorithms": ["algorithm", "sort", "search", "递归", "算法"],
            "oop": ["class", "object", "inherit", "继承", "面向对象"],
            "web_development": ["flask", "django", "html", "css", "javascript", "前端"],
            "data_science": ["pandas", "numpy", "机器学习", "数据分析"],
            "python_basics": ["python", "def", "function", "变量", "函数", "语法"],
        }
        for topic, keywords in topic_keywords.items():
            if any(keyword in lowered for keyword in keywords):
                return topic
        return "general_programming"
